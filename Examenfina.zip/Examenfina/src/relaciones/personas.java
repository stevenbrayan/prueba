package relaciones;

import java.util.Scanner;
import java.util.List;

public class personas {
   
    Scanner leer=new Scanner(System.in);
    private int nroCedula;
    
    private String nombrecompleto;
    
    private String expedido;
    //// relacion de asociacion de 1 a 1
    //
     private Automovil automovil;
    // relacion de asociacion de 1 a n
    
    //private List<Automovil> listaAutomovil;
    
    
    public void registrarPersonas() {

        System.out.println("digite el numero de cedula dela persona");
        this.nroCedula = leer.nextInt();
        leer.nextLine();
        System.out.println("digite el nombre completo de la persona");
        this.nombrecompleto = leer.nextLine();
        System.out.println("digite el lugar de expedido de la cedula");
        this.expedido = leer.nextLine();
        // llamar al metodo del registror de los datos de automovil
        // instanciar automovil
        
        
        
        automovil=new Automovil();
        automovil.registrarAutomovil();
    }
    
    public void mostrarpersona() {

        System.out.println("numero de la cedula :" + this.nroCedula);
        System.out.println(" expedido de la cedula:" + this.expedido);
        System.out.println(" su nombre completo:" + this.nombrecompleto);
        
        if(automovil != null){
                  
            automovil.mostrarAutomovil();
        }
    
    }   

    public int getNroCedula() {
        return nroCedula;
    }

    public void setNroCedula(int nroCedula) {
        this.nroCedula = nroCedula;
    }

    public String getNombrecompleto() {
        return nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

    public String getExpedido() {
        return expedido;
    }

    public void setExpedido(String expedido) {
        this.expedido = expedido;
    }

    public Automovil getAutomovil() {
        return automovil;
    }

    public void setAutomovil(Automovil automovil) {
        this.automovil = automovil;
    }

    
    
    
    
   
    
    
}
