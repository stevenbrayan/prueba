
package relaciones;

import java.util.Scanner;


public class BoletaInfraccion {
  
    Scanner leer=new Scanner (System.in);
    private int nroBoleta;
    
    private String nombreConductor;
    private String  fecha;
    private String lugar;
    private String tipoInfraccion;
    private int costo;
    private String estado;
    
    public void llenarInfraccion(){
        System.out.println("Digite el numero de boleta");
        this.nroBoleta=leer.nextInt();
        leer.nextLine();
        System.out.println("Digite el nombre del conductor que ocasiono la Infraccion");
        this.nombreConductor=leer.nextLine();
        System.out.println("Digite la fecha de Infraccion dd/mm/aa");
        this.fecha=leer.nextLine();
        System.out.println("Digite el lugar de la infraccion ");
        this.lugar=leer.nextLine();
        System.out.println("Digite el tipo de Infraccion");
        this.tipoInfraccion=leer.nextLine();
        
       
        System.out.println("Digite el costo de la Infraccion");
        this.costo=leer.nextInt();
        System.out.println("");
        
        this.estado="EMITIDO";
        System.out.println("BOLETA DE INFRACCION REGISTRADA");
        System.out.println("");
        
        
    }
    
    public void mostrarBoleta(){
        System.out.println("nro.Boleta:"+this.nroBoleta);
        System.out.println("nombre conductor:"+this.nombreConductor);
        System.out.println("fecha:"+this.fecha);
        System.out.println("lugar:"+this.lugar);
        System.out.println("tipo de Infraccion:"+this.tipoInfraccion);
        System.out.println("costo de Infraccion:"+this.costo);
        System.out.println("estado:"+this.estado);
        System.out.println("--------------------------------------------------");
    }

    public int getNroBoleta() {
        return nroBoleta;
    }

    public void setNroBoleta(int nroBoleta) {
        this.nroBoleta = nroBoleta;
    }

    public String getNombreConductor() {
        return nombreConductor;
    }

    public void setNombreConductor(String nombreConductor) {
        this.nombreConductor = nombreConductor;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getTipoInfraccion() {
        return tipoInfraccion;
    }

    public void setTipoInfraccion(String tipoInfraccion) {
        this.tipoInfraccion = tipoInfraccion;
    }

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
