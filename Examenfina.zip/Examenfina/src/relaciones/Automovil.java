package relaciones;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Automovil {
     Scanner leer=new Scanner(System.in);
    private String placa;
    private String marca;
    private String modelo;
    private String color;
    /// definiendo la relacion de agregacion de la boleta
    private List<BoletaInfraccion>listaBoletas;
    
    // contructor

    public Automovil() {
       listaBoletas=new ArrayList<>();
    }
    
    

    
    
    public void registrarAutomovil(){
        System.out.println("digite la placa delo automovil");
        this.placa=leer.nextLine();
        System.out.println("digite el color del carro");
        this. color=leer.nextLine();
         System.out.println("digite la marca");
        this. marca=leer.nextLine();
       
        System.out.println("digite el modelo del automovil");
        this.modelo=leer.nextLine();
        
    }
    
    public void mostrarAutomovil(){
      
        System.out.println("la placa del auto es:"+this.placa);
        System.out.println("la marca del auto es:"+this.marca);
        System.out.println(" el color del auto es :"+this.color);
        System.out.println("la marca del carro es :"+this.modelo); 
        
        if(listaBoletas !=null && listaBoletas.size()>0){
            System.out.println("------BOLETA  DE INFRACCION REGISTRADA PARA AUTOMOVIL-------");
            
            for(BoletaInfraccion boleta:listaBoletas){
               boleta.mostrarBoleta();
            }
        }else{
            System.out.println("NO TIENE INFRACCION REGISTRADAs");
        }
    } 
    /// adiciona dentro de listaboleta el objeto boletas
    //  la boleta creada por el funcionario de transito
    
    public void adicionarBoletas(BoletaInfraccion boletas){
        if(listaBoletas !=null){
            listaBoletas.add(boletas);
            System.out.println("Boleta de Infraccion adicionado al Automovil"+this.placa);       
        }
        
    }

    public List<BoletaInfraccion> getListaBoletas() {
        return listaBoletas;
    }

    public void setListaBoletas(List<BoletaInfraccion> listaBoletas) {
        this.listaBoletas = listaBoletas;
    }
    
    
    

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    
   
    
     
     
}