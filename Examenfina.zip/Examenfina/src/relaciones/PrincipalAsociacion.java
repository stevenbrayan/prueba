package relaciones;

import java.util.Scanner;

public class PrincipalAsociacion {

    public static void main(String[] args) {
        OperacionesPersonasAutomovil obj = new OperacionesPersonasAutomovil();
        
        BoletaInfraccion boleta=new BoletaInfraccion();
        int nb=0;
        String res;
        Scanner leer = new Scanner(System.in);
        int opc;
        boolean continuar = true;

        do {
            System.out.println("MENU DE OPCIONES");
            System.out.println("1-registrar Usuario");
            System.out.println("2-llenar boleta de infraccion");
            System.out.println("3-mostrar usuario");
            System.out.println("4-pagar boleta de infraccion");
            System.out.println("5-salir");
            System.out.println("DIGITE UNA OPCION");
            opc = leer.nextInt();

            switch (opc) {
                case 1:
                    obj.registroUsuario();
                    break;

                case 2:
                    obj.crearBoletaInfraccion();
                    break;
                case 3:
                    obj.mostrarUsuario();
                    break;
                case 4:
                    obj.pagarBoletaInfraccion();
                    
                    break;

                
                  

                default:

                    continuar = false;
                    break;

            }

        } while (continuar);
    }
}
