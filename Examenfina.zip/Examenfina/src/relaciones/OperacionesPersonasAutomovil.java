package relaciones;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OperacionesPersonasAutomovil {

    Scanner leer = new Scanner(System.in);
    List<personas> listapersonas;

    personas personas;
    BoletaInfraccion boleta;

    public OperacionesPersonasAutomovil(List<personas> listapersonas) {
        this.listapersonas = listapersonas;
    }

    public OperacionesPersonasAutomovil() {
        listapersonas = new ArrayList<>();
    }

    //metodos
    public void registroUsuario() {
        personas = new personas();

        personas.registrarPersonas();
        listapersonas.add(personas);
        System.out.println("Usuario registrado en el sistema");
        System.out.println("");

    }

    public void mostrarUsuario() {
        if (listapersonas != null && listapersonas.size() > 0) {
            System.out.println("listado de usuario del sistema");
            for (personas persona : listapersonas) {

                persona.mostrarpersona();
                System.out.println("--------------------------------------");
            }

        }
    }

    public void crearBoletaInfraccion() {

        if (personas.getAutomovil() != null) {
            boleta = new BoletaInfraccion();
            boleta.llenarInfraccion();
            personas.getAutomovil().adicionarBoletas(boleta);
        } else {
            System.out.println("LA PERSONA NO TIENE ASOCIADO UN VEICULO");
        }
    }

    public void pagarBoletaInfraccion() {
        int nb = 0;
        String res = "";
        if (personas.getAutomovil().getListaBoletas().size() > 0) {
            System.out.println("----------INFRACCIONES DEL VEICULO NO CONCELADO------");

            for (BoletaInfraccion boleta : personas.getAutomovil().getListaBoletas()) {
                if (boleta.getEstado().equalsIgnoreCase("EMITIDO")) {
                    boleta.mostrarBoleta();
                }  
            
            }
            
           // preguntando cual de las infracciones desea canselar de todos las que tiene pendientes 
           for (BoletaInfraccion boleta : personas.getAutomovil().getListaBoletas()) { // preguntando cual de las infracciones desea canselar de todos las que tiene pendientes
              System.out.println("DIGITE EL NUMERO DE BOLETA que desea cancelar:");
              nb = leer.nextInt(); 
              System.out.println("");
            
     
             
            
                if (nb == boleta.getNroBoleta()) {
                    
                    System.out.println("DESEA CANCELAR LA INFRACCION DE " + boleta.getCosto() + "BS,s/n :");
                    res = leer.next();
                    System.out.println("");

                    if (res.equalsIgnoreCase("s")) {
                        boleta.setEstado("CANCELADO");
                        System.out.println("SE cancelo la infraccion correctamente");
                        System.out.println("");
                    } else  {
                        System.out.println("");
                        System.out.println("OPERACION DE CANCELACION NO REALIZADO");

                    }

                } 
            }

        }

    }

}
